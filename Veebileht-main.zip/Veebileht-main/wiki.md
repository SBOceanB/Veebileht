Veebileht tutvustab rahakotisõbralikke söögikohti tudengitele Tartus.

Rühma käitumisnormid:
1. Osaleb aktiivselt koosolekutel 
2. Täidab oma rolli ülesandeid
3. Lahendab ülesanded õigeks ajaks
4. Annab vajaminevat tagasiside
5. On kursis tehtud tööde ja tähtaegadega

